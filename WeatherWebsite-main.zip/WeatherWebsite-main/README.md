# Weather Website
<h3>You can type in the Country,City you want to know its weather and get back information using Weather API = ) </h3>
<h2></h2>
<img width=500 height=500 src="https://user-images.githubusercontent.com/82037460/188455019-963a31c5-1416-41b6-9324-a01678ef3168.PNG"</img>
<h2></h2>
<img width=500 height=500 src="https://user-images.githubusercontent.com/82037460/188456595-98c08808-2616-4157-8f14-370f84729878.PNG"</img>
<h2></h2>
<img width=500 height=500 src="https://user-images.githubusercontent.com/82037460/188457371-ce81c2c2-175e-47c3-a512-8992ab86924c.PNG"</img>
